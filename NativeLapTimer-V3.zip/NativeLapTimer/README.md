# Native Lap Timer 3.0 (Android)

Native Kotlin + Jetpack Compose lap timer. No browser, WebView, PWA, or JavaScript.

## Version 3

- Persistent foreground-service notification while the timer is active, with Lap, Pause/Resume, and Stop controls.
- Home-screen widget with elapsed time and Start/Pause/Resume, Lap, and Open controls.
- Automatic lap-name prompt immediately after recording a lap in the app. The lap is committed before the prompt appears; Skip retains the default name.
- A lap recorded from the notification/widget is saved immediately. Open the notification's Name lap action to name it in the app (Android does not permit arbitrary background dialogs).
- Updated minimalist dark launcher icon with silver stopwatch and muted burgundy accent.

## Timing and storage

- Elapsed time is calculated from `SystemClock.elapsedRealtime()`; the UI refresh loop is not the clock source.
- Timer state and lap records are stored locally using synchronous SharedPreferences commits for user actions.
- Timer state can be reconstructed after the UI process is killed.
- The foreground service supplies persistent user-visible controls; it is not used as the timing source.
- A reboot interval is bridged using wall-clock time once, then monotonic timing resumes. Wall-clock changes during that exceptional interval can affect the bridge.

## Build

The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile SDK 35, and Gradle 8.9 in the supplied GitHub Actions workflow. Build with:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

The first install/run should grant notification permission so the persistent notification can be displayed. Add the Lap Timer widget from the Android launcher's Widgets panel.

## Important testing

This V3 archive has been structurally inspected and the known Kotlin visibility issue is corrected. It has not been compiled or device-tested in this environment. Build it through GitHub Actions, install the APK, and test timer continuity, notification controls, widget controls, lap naming, app process death, and device reboot before relying on it for important records.
