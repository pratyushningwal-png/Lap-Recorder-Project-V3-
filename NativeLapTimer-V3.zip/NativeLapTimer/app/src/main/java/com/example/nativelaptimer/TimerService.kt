package com.example.nativelaptimer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import java.util.UUID

class TimerService : Service() {
    private lateinit var store: TimerStore

    override fun onCreate() {
        super.onCreate()
        store = TimerStore(this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // A widget action can start this service while the timer is paused; enter foreground
        // immediately so Android's foreground-service start deadline is always respected.
        startForeground(NOTIFICATION_ID, buildNotification(store.load()))
        when (intent?.action) {
            ACTION_START -> startTimer()
            ACTION_TOGGLE -> toggleTimer()
            ACTION_LAP -> recordLap()
            ACTION_PAUSE -> pauseTimer(keepNotification = true)
            ACTION_STOP -> pauseTimer(keepNotification = false)
            ACTION_SYNC, null -> syncFromSavedState()
        }
        return START_NOT_STICKY
    }

    private fun syncFromSavedState() {
        val state = store.load()
        if (state.running) {
            startForeground(NOTIFICATION_ID, buildNotification(state))
        } else {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        WidgetUpdater.update(this, state)
    }

    private fun startTimer() {
        var state = store.load()
        if (!state.running) {
            val boot = try { android.provider.Settings.Global.getInt(contentResolver, android.provider.Settings.Global.BOOT_COUNT, 0) } catch (_: Exception) { 0 }
            state = state.copy(running = true, startedElapsed = SystemClock.elapsedRealtime(), startedWall = System.currentTimeMillis(), bootCount = boot)
            store.save(state)
        }
        startForeground(NOTIFICATION_ID, buildNotification(state))
        WidgetUpdater.update(this, state)
    }

    private fun toggleTimer() {
        val state = store.load()
        if (state.running) pauseTimer(keepNotification = true) else startTimer()
    }

    private fun pauseTimer(keepNotification: Boolean = false) {
        val state = store.load()
        if (state.running) {
            val elapsed = state.accumulatedMs + (SystemClock.elapsedRealtime() - state.startedElapsed).coerceAtLeast(0L)
            val paused = state.copy(running = false, accumulatedMs = elapsed, startedElapsed = 0L, startedWall = 0L)
            store.save(paused)
            WidgetUpdater.update(this, paused)
        }
        if (keepNotification) {
            startForeground(NOTIFICATION_ID, buildNotification(store.load()))
        } else {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun recordLap() {
        val state = store.load()
        if (!state.running) return
        val elapsed = state.accumulatedMs + (SystemClock.elapsedRealtime() - state.startedElapsed).coerceAtLeast(0L)
        val previousTotal = state.laps.firstOrNull()?.totalMs ?: 0L
        val lap = Lap(UUID.randomUUID().toString(), "Lap ${state.laps.size + 1}", (elapsed - previousTotal).coerceAtLeast(0L), elapsed, System.currentTimeMillis())
        val next = state.copy(laps = listOf(lap) + state.laps)
        store.save(next)
        getSharedPreferences("lap_timer_store", MODE_PRIVATE).edit().putString("pending_name_lap_id", lap.id).apply()
        startForeground(NOTIFICATION_ID, buildNotification(next, lap.id))
        WidgetUpdater.update(this, next)
    }

    private fun buildNotification(state: TimerState, lapToName: String? = getSharedPreferences("lap_timer_store", MODE_PRIVATE).getString("pending_name_lap_id", null)): Notification {
        val elapsed = if (state.running) state.accumulatedMs + (SystemClock.elapsedRealtime() - state.startedElapsed).coerceAtLeast(0L) else state.accumulatedMs
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            if (lapToName != null) putExtra(EXTRA_NAME_LAP_ID, lapToName)
        }
        val openPending = PendingIntent.getActivity(this, 10, openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val lapPending = servicePending(ACTION_LAP, 11)
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Lap Timer · ${formatTime(elapsed)}")
            .setContentText(if (lapToName != null) "Lap recorded · Tap to name it" else if (state.running) "Timer running · Tap to open" else "Timer paused · Resume from notification")
            .setContentIntent(openPending)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory("stopwatch")
            .setWhen(System.currentTimeMillis() - elapsed)
            .setUsesChronometer(state.running)
            .addAction(if (state.running) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play, if (state.running) "Pause" else "Resume", servicePending(ACTION_TOGGLE, 12))
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", servicePending(ACTION_STOP, 13))
        if (state.running) builder.addAction(android.R.drawable.ic_menu_add, "Lap", lapPending)
        if (lapToName != null) builder.addAction(android.R.drawable.ic_menu_edit, "Name lap", openPending)
        return builder.build()
    }

    private fun servicePending(action: String, request: Int): PendingIntent {
        val i = Intent(this, TimerService::class.java).setAction(action)
        return PendingIntent.getService(this, request, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Lap Timer", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Persistent controls while the lap timer is running"
                setShowBadge(false)
            })
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL_ID = "lap_timer_running"
        const val NOTIFICATION_ID = 4102
        const val ACTION_START = "com.example.nativelaptimer.START"
        const val ACTION_TOGGLE = "com.example.nativelaptimer.TOGGLE"
        const val ACTION_LAP = "com.example.nativelaptimer.LAP"
        const val ACTION_PAUSE = "com.example.nativelaptimer.PAUSE"
        const val ACTION_STOP = "com.example.nativelaptimer.STOP"
        const val ACTION_SYNC = "com.example.nativelaptimer.SYNC"
        const val EXTRA_NAME_LAP_ID = "name_lap_id"
    }
}

object WidgetUpdater {
    internal fun update(context: Context, state: TimerState) {
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, LapTimerWidget::class.java))
        if (ids.isNotEmpty()) LapTimerWidget.updateAll(context, manager, ids, state)
    }
}

class LapTimerWidget : android.appwidget.AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val state = TimerStore(context).load()
        updateAll(context, manager, ids, state)
    }

    companion object {
        internal fun updateAll(context: Context, manager: AppWidgetManager, ids: IntArray, state: TimerState) {
            val elapsed = if (state.running) state.accumulatedMs + (SystemClock.elapsedRealtime() - state.startedElapsed).coerceAtLeast(0L) else state.accumulatedMs
            ids.forEach { id ->
                val views = android.widget.RemoteViews(context.packageName, R.layout.widget_lap_timer)
                views.setTextViewText(R.id.widget_status, if (state.running) "RUNNING" else "PAUSED")
                if (state.running) {
                    views.setViewVisibility(R.id.widget_clock, android.view.View.VISIBLE)
                    views.setViewVisibility(R.id.widget_static_time, android.view.View.GONE)
                    views.setChronometer(R.id.widget_clock, SystemClock.elapsedRealtime() - elapsed, null, true)
                } else {
                    views.setViewVisibility(R.id.widget_clock, android.view.View.GONE)
                    views.setViewVisibility(R.id.widget_static_time, android.view.View.VISIBLE)
                    views.setTextViewText(R.id.widget_static_time, formatTime(elapsed))
                }
                views.setOnClickPendingIntent(R.id.widget_toggle, servicePending(context, TimerService.ACTION_TOGGLE, id + 100))
                views.setTextViewText(R.id.widget_toggle, if (state.running) "PAUSE" else if (elapsed > 0L) "RESUME" else "START")
                views.setOnClickPendingIntent(R.id.widget_lap, servicePending(context, TimerService.ACTION_LAP, id + 200))
                views.setOnClickPendingIntent(R.id.widget_open, PendingIntent.getActivity(context, id + 300, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
                manager.updateAppWidget(id, views)
            }
        }

        private fun servicePending(context: Context, action: String, request: Int): PendingIntent {
            val intent = Intent(context, TimerService::class.java).setAction(action)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            return if (Build.VERSION.SDK_INT >= 26) PendingIntent.getForegroundService(context, request, intent, flags)
            else PendingIntent.getService(context, request, intent, flags)
        }
    }
}
