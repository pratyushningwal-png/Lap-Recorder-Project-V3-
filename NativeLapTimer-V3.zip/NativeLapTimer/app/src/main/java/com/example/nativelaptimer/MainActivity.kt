package com.example.nativelaptimer

import android.content.Context
import android.os.Bundle
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private val Bg = Color(0xFF0B0D12)
private val Panel = Color(0xFF151923)
private val Muted = Color(0xFF929AAA)
private val Accent = Color(0xFF8AB4F8)
private val White = Color(0xFFF2F4F8)

internal data class Lap(
    val id: String,
    val name: String,
    val splitMs: Long,
    val totalMs: Long,
    val createdAt: Long
)

internal data class TimerState(
    val running: Boolean = false,
    val accumulatedMs: Long = 0L,
    val startedElapsed: Long = 0L,
    val startedWall: Long = 0L,
    val bootCount: Int = 0,
    val laps: List<Lap> = emptyList()
)

internal class TimerStore(context: Context) {
    private val prefs = context.getSharedPreferences("lap_timer_store", Context.MODE_PRIVATE)
    private val appContext = context.applicationContext

    private fun currentBootCount(): Int = try {
        Settings.Global.getInt(appContext.contentResolver, Settings.Global.BOOT_COUNT, 0)
    } catch (_: Exception) { 0 }

    fun load(): TimerState {
        val raw = prefs.getString("state", null) ?: return TimerState(bootCount = currentBootCount())
        return try {
            val o = JSONObject(raw)
            val arr = o.optJSONArray("laps") ?: JSONArray()
            val laps = buildList {
                for (i in 0 until arr.length()) {
                    val x = arr.getJSONObject(i)
                    add(Lap(
                        id = x.optString("id", UUID.randomUUID().toString()),
                        name = x.optString("name", "Lap"),
                        splitMs = x.optLong("splitMs", 0L),
                        totalMs = x.optLong("totalMs", 0L),
                        createdAt = x.optLong("createdAt", System.currentTimeMillis())
                    ))
                }
            }
            var state = TimerState(
                running = o.optBoolean("running", false),
                accumulatedMs = o.optLong("accumulatedMs", 0L),
                startedElapsed = o.optLong("startedElapsed", 0L),
                startedWall = o.optLong("startedWall", 0L),
                bootCount = o.optInt("bootCount", currentBootCount()),
                laps = laps
            )
            val boot = currentBootCount()
            if (state.running && state.bootCount != boot) {
                // elapsedRealtime resets at reboot. Bridge the reboot using wall time once,
                // then return to monotonic elapsedRealtime for all subsequent timing.
                val bridge = (System.currentTimeMillis() - state.startedWall).coerceAtLeast(0L)
                state = state.copy(
                    accumulatedMs = state.accumulatedMs + bridge,
                    startedElapsed = SystemClock.elapsedRealtime(),
                    startedWall = System.currentTimeMillis(),
                    bootCount = boot
                )
                save(state)
            }
            state
        } catch (_: Exception) {
            TimerState(bootCount = currentBootCount())
        }
    }

    fun save(s: TimerState) {
        val arr = JSONArray()
        s.laps.forEach { lap ->
            arr.put(JSONObject().apply {
                put("id", lap.id); put("name", lap.name)
                put("splitMs", lap.splitMs); put("totalMs", lap.totalMs)
                put("createdAt", lap.createdAt)
            })
        }
        val o = JSONObject().apply {
            put("running", s.running); put("accumulatedMs", s.accumulatedMs)
            put("startedElapsed", s.startedElapsed); put("startedWall", s.startedWall)
            put("bootCount", s.bootCount); put("laps", arr)
        }
        // commit() writes synchronously so a tap is persisted before the UI moves on.
        prefs.edit().putString("state", o.toString()).commit()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(11, 13, 18)
        window.navigationBarColor = android.graphics.Color.rgb(11, 13, 18)
        window.decorView.systemUiVisibility = 0
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 701)
        }
        setContent { LapTimerApp() }
    }
}

@Composable
private fun LapTimerApp() {
    val context = LocalContext.current
    val store = remember { TimerStore(context) }
    var state by remember { mutableStateOf(store.load()) }
    var now by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    var editingLap by remember { mutableStateOf<Lap?>(null) }
    var nameDraft by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        val activity = context as? ComponentActivity
        val requestedLapId = activity?.intent?.getStringExtra(TimerService.EXTRA_NAME_LAP_ID)
            ?: context.getSharedPreferences("lap_timer_store", Context.MODE_PRIVATE).getString("pending_name_lap_id", null)
        if (requestedLapId != null) {
            state.laps.firstOrNull { it.id == requestedLapId }?.let { editingLap = it; nameDraft = it.name }
        }
    }

    LaunchedEffect(Unit) {
        var lastReload = 0L
        while (true) {
            now = SystemClock.elapsedRealtime()
            if (now - lastReload >= 500L) {
                val latest = store.load()
                if (latest != state) state = latest
                val pendingId = context.getSharedPreferences("lap_timer_store", Context.MODE_PRIVATE).getString("pending_name_lap_id", null)
                if (pendingId != null && editingLap == null) {
                    latest.laps.firstOrNull { it.id == pendingId }?.let { editingLap = it; nameDraft = it.name }
                }
                lastReload = now
            }
            delay(100L)
        }
    }

    val elapsed = if (state.running) {
        state.accumulatedMs + (now - state.startedElapsed).coerceAtLeast(0L)
    } else state.accumulatedMs

    fun persist(next: TimerState) {
        state = next
        store.save(next)
        WidgetUpdater.update(context, next)
        val serviceIntent = android.content.Intent(context, TimerService::class.java).setAction(TimerService.ACTION_SYNC)
        try {
            if (next.running) {
                if (android.os.Build.VERSION.SDK_INT >= 26) context.startForegroundService(serviceIntent) else context.startService(serviceIntent)
            } else context.startService(serviceIntent)
        } catch (_: Exception) { }
    }

    fun vibrate() {
        try {
            val vibrator = if (android.os.Build.VERSION.SDK_INT >= 31) {
                (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else @Suppress("DEPRECATION") (context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
            if (android.os.Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(28, 75))
            else @Suppress("DEPRECATION") vibrator.vibrate(28)
        } catch (_: Exception) { }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Accent,
        onBackground = White, onSurface = White
    )) {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            Column(
                modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("LAP TIMER", color = Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Spacer(Modifier.weight(1f))
                    Text(if (state.running) "RUNNING" else "STOPPED", color = if (state.running) Accent else Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(42.dp))
                Text(formatTime(elapsed), color = White, fontSize = 48.sp, fontWeight = FontWeight.Light, textAlign = TextAlign.Center, maxLines = 1)
                Spacer(Modifier.height(8.dp))
                Text("TOTAL ELAPSED TIME", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(34.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(
                        onClick = {
                            val t = SystemClock.elapsedRealtime()
                            val next = if (state.running) {
                                state.copy(running = false, accumulatedMs = elapsed, startedElapsed = 0L, startedWall = 0L)
                            } else {
                                state.copy(running = true, startedElapsed = t, startedWall = System.currentTimeMillis(), bootCount = try { Settings.Global.getInt(context.contentResolver, Settings.Global.BOOT_COUNT, 0) } catch (_: Exception) { 0 })
                            }
                            persist(next)
                        },
                        modifier = Modifier.weight(1f).height(54.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = if (state.running) Color(0xFF343B49) else Accent, contentColor = if (state.running) White else Color(0xFF101722))
                    ) { Text(if (state.running) "PAUSE" else if (elapsed > 0L) "RESUME" else "START", fontWeight = FontWeight.Bold) }
                    OutlinedButton(
                        onClick = {
                            if (state.running) {
                                val split = (elapsed - (state.laps.firstOrNull()?.totalMs ?: 0L)).coerceAtLeast(0L)
                                val lap = Lap(UUID.randomUUID().toString(), "Lap ${state.laps.size + 1}", split, elapsed, System.currentTimeMillis())
                                persist(state.copy(laps = listOf(lap) + state.laps))
                                editingLap = lap
                                nameDraft = lap.name
                                vibrate()
                            }
                        },
                        enabled = state.running,
                        modifier = Modifier.weight(1f).height(54.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text("LAP", fontWeight = FontWeight.Bold) }
                }
                Spacer(Modifier.height(12.dp))
                TextButton(
                    onClick = { persist(TimerState(bootCount = try { Settings.Global.getInt(context.contentResolver, Settings.Global.BOOT_COUNT, 0) } catch (_: Exception) { 0 })) },
                    enabled = !state.running && (elapsed > 0L || state.laps.isNotEmpty())
                ) { Text("RESET TIMER", color = Muted) }
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("LAP HISTORY", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                    Spacer(Modifier.weight(1f))
                    Text("${state.laps.size} LAPS", color = Muted, fontSize = 11.sp)
                }
                Spacer(Modifier.height(10.dp))
                if (state.laps.isEmpty()) {
                    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Text("Your recorded laps will appear here.", color = Muted, fontSize = 13.sp)
                    }
                } else {
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(state.laps, key = { it.id }) { lap ->
                            Row(
                                Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(horizontal = 14.dp, vertical = 13.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(lap.name, color = White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                    Text(SimpleDateFormat("dd MMM · hh:mm:ss a", Locale.getDefault()).format(Date(lap.createdAt)), color = Muted, fontSize = 10.sp)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(formatTime(lap.splitMs), color = White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                    Text("TOTAL ${formatTime(lap.totalMs)}", color = Muted, fontSize = 9.sp)
                                }
                                Spacer(Modifier.width(8.dp))
                                TextButton(onClick = { editingLap = lap; nameDraft = lap.name }) { Text("EDIT", fontSize = 10.sp) }
                            }
                        }
                    }
                }
                Text("Saved on this device · Works offline", color = Color(0xFF606979), fontSize = 10.sp, modifier = Modifier.padding(top = 8.dp, bottom = 2.dp))
            }
        }
    }

    editingLap?.let { lap ->
        AlertDialog(
            onDismissRequest = {
                editingLap = null
                context.getSharedPreferences("lap_timer_store", Context.MODE_PRIVATE).edit().remove("pending_name_lap_id").apply()
                try { context.startService(android.content.Intent(context, TimerService::class.java).setAction(TimerService.ACTION_SYNC)) } catch (_: Exception) { }
            },
            title = { Text("Rename lap") },
            text = { OutlinedTextField(value = nameDraft, onValueChange = { nameDraft = it }, singleLine = true, label = { Text("Lap name") }) },
            confirmButton = {
                TextButton(onClick = {
                    val cleaned = nameDraft.trim().ifBlank { lap.name }
                    persist(state.copy(laps = state.laps.map { if (it.id == lap.id) it.copy(name = cleaned) else it }))
                    editingLap = null
                    context.getSharedPreferences("lap_timer_store", Context.MODE_PRIVATE).edit().remove("pending_name_lap_id").apply()
                try { context.startService(android.content.Intent(context, TimerService::class.java).setAction(TimerService.ACTION_SYNC)) } catch (_: Exception) { }
                }) { Text("SAVE") }
            },
            dismissButton = { TextButton(onClick = {
                editingLap = null
                context.getSharedPreferences("lap_timer_store", Context.MODE_PRIVATE).edit().remove("pending_name_lap_id").apply()
                try { context.startService(android.content.Intent(context, TimerService::class.java).setAction(TimerService.ACTION_SYNC)) } catch (_: Exception) { }
            }) { Text("SKIP") } }
        )
    }
}

internal fun formatTime(ms: Long): String {
    val total = (ms / 10L).coerceAtLeast(0L)
    val centiseconds = total % 100L
    val seconds = (total / 100L) % 60L
    val minutes = (total / 6_000L) % 60L
    val hours = total / 360_000L
    return String.format(Locale.getDefault(), "%02d:%02d:%02d.%02d", hours, minutes, seconds, centiseconds)
}
